package com.example.adeline.android_ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LinearLayoutVActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linear_layout_v);
    }
}
